from flask import Flask, request, render_template, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import random
import io
from PIL import Image, ImageDraw, ImageFont
import base64

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # 用于保存session

# 伪数据库
fake_db = {
    'user1': generate_password_hash('password123'),  # 用户 user1，密码为 'password123'
    'user2': generate_password_hash('password789'),
    'user3': generate_password_hash('password456'),

}

# 生成验证码
def generate_captcha():
    image = Image.new('RGB', (100, 40), (255, 255, 255))
    draw = ImageDraw.Draw(image)
    
    # 验证码字符
    captcha_text = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=4))
    
    # 使用系统默认字体
    try:
        font = ImageFont.truetype('static/fonts/arial.ttf', 24)
    except IOError:
        font = ImageFont.load_default()
    
    draw.text((10, 5), captcha_text, font=font, fill=(0, 0, 0))
    
    # 保存验证码到session
    session['captcha'] = captcha_text

    # 将图片转为字节流
    buffer = io.BytesIO()
    image.save(buffer, 'PNG')
    img_str = base64.b64encode(buffer.getvalue()).decode('utf-8')

    return img_str

@app.route('/')
def index():
    captcha_image = generate_captcha()
    return render_template('login.html', captcha_image=captcha_image)

@app.route('/login', methods=['POST'])
def do_login():
    username = request.form.get('username')
    password = request.form.get('password')
    captcha = request.form.get('captcha')
    
    # 验证验证码
    if captcha != session.get('captcha'):
        return "验证码错误，请重新输入"

    # 验证用户名和密码
    if username in fake_db and check_password_hash(fake_db[username], password):
        return render_template('success.html')
    else:
        return "用户名或密码错误"

if __name__ == '__main__':
    app.run(debug=True)